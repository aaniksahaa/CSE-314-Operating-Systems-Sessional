#!/bin/bash

echo "1 2 3"
echo "4 5 6"
echo "7 8 9"
echo "10 11 12"
echo "13 14 15"
echo "16 17 18"
echo "19 20 21"
echo "22 23 24"
echo "25 26 27"
echo "28 29 30"
echo "19 20 21"
