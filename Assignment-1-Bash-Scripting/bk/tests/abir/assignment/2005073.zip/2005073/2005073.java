public class PrintNumbers {
    public static void main(String[] args) {
        System.out.println("1 2 3");
        System.out.println("4 5 6");
        System.out.println("7 8 9");
        System.out.println("10 11 12");
        System.out.println("13 14 15");
        System.out.println("16 17 18");
        System.out.println("19 20 21");
        System.out.println("22 23 24");
        System.out.println("25 26 27");
        System.out.println("28 29 30");
    }
}
