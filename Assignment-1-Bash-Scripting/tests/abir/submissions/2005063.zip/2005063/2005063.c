#include <stdio.h>

int main() {
    printf("1 2 3\n");
    printf("28 29 30\n");
    printf("4 5 6\n");
    printf("7 8 9\n");
    printf("10 11 12\n");
    printf("13 14 15\n");

    
    printf("22 23 24\n");
    printf("19 20 21\n");
    printf("25 26 27\n");
    

    return 0;
}
